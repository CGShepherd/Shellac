# Project Shellac — Native KiCad 9.0.7 Scaffold A0

This pack is the first native KiCad scaffold. It is deliberately minimal and should open directly in KiCad 9.0.7.

## Contents

- ProjectShellac.kicad_pro
- ProjectShellac.kicad_sch
- SCH-101 through SCH-106 child sheets

## Next step

Open `ProjectShellac.kicad_pro` in KiCad 9.0.7 and confirm:
1. Project opens.
2. Top-level schematic opens.
3. Six child sheets are visible.
4. Double-clicking each child sheet opens the correct page.

This scaffold contains sheet hierarchy and engineering notes only. Components will be added in the next generator increment.
