# Project Shellac Generator — Sprint 0.1

Small, reviewable generator framework commit.

## Run

```cmd
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python -m pytest
python scripts\build_minimal_project.py
```

Open:

```text
out/kicad/ProjectShellac.kicad_pro
```

Sprint 0.1 verifies the generator foundation only. SCH-101 generation follows in Sprint 0.2.
