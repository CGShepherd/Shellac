# Project Shellac Native KiCad A1

Open ProjectShellac.kicad_pro in KiCad 9.0.7. A1 adds a populated SCH-101 sheet with embedded local symbols.
